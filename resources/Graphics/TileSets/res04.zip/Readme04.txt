	GAME MAKER RESOURCE PACK 04

This zip file contains some additional
resources (example games, sounds, sprites,
tiles) for Game Maker version 7.

This resource pack consists of sprites, background,
tiles, loading images, and game icons created by:

Morphosis Enter-Active Graphics
Author: John Hempstead
Internet: http://mea.gmcommunity.com/mea
email: morphosisgames@aol.com
Copyright (C) 2001-2003 John Hempstead. 
All Rights Reserved.


ATTENTION: READ CAREFULLY
=========================

Graphics created by Morphosis Enter-Active are property
by Morphosis Enter-Active, John Hempstead. � 2001-2003. 

Usage:
------------------------------------------
They can be used FREE for your NON-COMMERCIAL and
NON-PROFIT game creations, multimedia creations,
programs or printable creations.

These graphics can be placed on your personal web site
for people to view and or download ONLY IF the author,
John Hempstead, Morphosis Enter-Active is clearly written
as the author on the web site and in ANY downloadable
files this License MUST be included.

You are not allowed to alter or change the contents of
the original graphics and distribute them as your own
full creations. You can change and alter them for
personal needs.

Credit:
------------------------------------------
Any use of the graphics in your creation must contain
credit to the creator in you game, multimedia project,
program, or printable material.

WARNING!!!

If YOU DO NOT follow the agreement, that's just rude
and I'll punch you! :)

Have fun.

John
Morphosis Enter-Active
:)
